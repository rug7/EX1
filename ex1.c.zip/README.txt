Student's Name: Majd Abdo

Id Number: 323055046

__________________________

What does this program do?

This program counts the letters and the words in a sentence from the user and saves the sentence and its information in the history,
the information is the number of letters(chars) and words in the input sentence.

__________________________
Methods used in this program:

1) int lines ( char* ) : this method takes a filename and returns the number of the lines in the file, 
   i used this method to give every sentence in the history file a number ,like shown in the homework.

2) void char ( char* , int* ,int*) : this method takes a char which is the input string from the user, 
   also it takes 2 pointers which points at the number of both the words and the letters in the sentence from the user.

3) int main() : in the main we check in an endless loop if the string entered from the user is equal to "exit"
   or if it's equal to "history" , anything besides that (else) the main uses the two methods up and prints the data on the screen
   and saves the string in it's place in the history file in it's own place.

  * case 1: if the string entered is "exit", the program stops and ends.

  * case 2: if the string entered is "history", the program opens the file which all the data are saved in, and prints to the screen every
   line in the correct order and continues till the program reaches the end of the file "EOF".
__________________________
How it compiles:
gcc main.c -o mainOutput
__________________________
How it opens the output(prints):
./mainOutput
__________________________
