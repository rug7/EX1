#include <stdio.h>
#include <string.h>
#include "stdlib.h"

//This method counts the lines in the file by opening the file and only read it and count
// so that we know where the file ends.
int lines(char* FileName){
    FILE* f;
    char ch;
    int count=0;
    f= fopen(FileName,"r");

    //getc gets the next char in a line so the first ch= getc(f) means that ch is the first char in the file
    //and if ch doesn't equal the end of the file then ch equals the next char in the line,
    //if ch equals to "\n" then there is a new line and the count is up by one.
    for(ch= getc(f); ch != EOF; ch= getc(f)){
        if(ch=='\n'){
            count++;
        }
    }
    fclose(f);
    return count;

}

//This method takes a char which is the input string from the user, also it takes 2 pointers which points
// at the number of both the words and the chars in the sentence from the user.

void chars(char* str,int* charCount, int* wordCount){
    int wordC=0;
    int charC=0;
    for (int i=0;str[i] != '\0';i++){

        //in this case we are looking for every char that is not a space
        //and by that we count the chars in a sentence
        if(str[i] != ' '){
            charC++;
        }

        //in this case we are looking for the space between words
        //and to achieve that we need to make sure there is only
        //one space between the words, it means
        //if the char in the location (i) is a space and the next location (i+1)
        //is not a space and the char count is over zero(means it is not an empty sentence),
        //then we add 1 to the words counter
        //or if the next location (i+1) is \0 that means the word ended ,and we have reached the end of the sentence.
        if((str[i]==' ' && charC > 0 && str[i+1] != ' ') || str[i+1] =='\0'){
            wordC++;
        }
    }

    *charCount=charC; //the pointer points at the value of the chars in the sentence.
    *wordCount=wordC; //the pointer points at the value of the words in the sentence.
}


int main() {
    char ca,Input[512];
    int lineC,words=0,letters=0;
    char HistoryList[]="Information";

    while(1){

        //instead of using "scanf" method to get the Input from the user
        //we use the "getc" method which is get the next char method
        //the difference between scanf and getc is that scanf scans the chars until the end of the word
        //but the getc method scans every char in the line till the end not till the end of the word.

        printf("Enter String, or < exit > to end program: \n");
            fgets(Input, 510, stdin);
            fflush(stdin);
            Input[strlen(Input) - 1]= '\0';


            //in this case if the Input equals is the word exit and only exit then the program stops
            //if the Input was "exit after 100 meters" for example, the program doesn't stop
            //and counts the chars and the words in the sentence.
            if(strcmp(Input, "exit") == 0){
                break;
            }

            //in this case if the Input equals is the word history and only history by itself the program
            //opens a file for reading and writing and writes in it all the past inputs from the user
            //and after the writing is over it prints the data on the screen.
            else if(strcmp(Input, "history") == 0 ){
                FILE* f;
                f= fopen(HistoryList, "a+");
                ca= fgetc(f);

                while(ca != EOF){
                    printf("%c",ca);
                    ca= fgetc(f);
                }
                fclose(f);
            }



            //in any other case besides the two which are up this , the program uses
            // the methods which I wrote to count both of words and chars in a word "without the spaces".
            //and after that we use the pointers which are hold the values of words and chars in a sentence
            //therefore opens a file only for writing saves the Input sentence in the correct place
            //in the history list file, and the closes the file.
            else {
                chars(Input, &letters, &words);
                printf("%d Words\n",words);
                printf("%d Chars\n",letters);
                FILE* f;
                f= fopen(HistoryList, "a");
                lineC= lines(HistoryList);
                fprintf(f, "%d : %s \n", lineC, Input);
                lineC++;
                fclose(f);
            }

    }


}